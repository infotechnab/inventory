<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            Inventory Is Easy
        </title>
        <style>
            html
            {
                margin: 0;
                padding: 0;
            }
            body
            {
                margin: 0;
                padding: 0;
                font-family:"Whitney SSm A","Whitney SSm B","Helvetica Neue",Helvetica,Arial,sans-serif;
            }
            #topNavigationWithSlider
            {
                background: #00620C url('http://localhost/inventory/content/images/inventrogb.jpg') no-repeat;
                width: 100%;
                height: 650px;
                border-bottom: 2px solid #fff;
            }
            #topNavigationDiv
            {
                margin: 0 auto 0 auto;

                height: 60px;
                background-color: #0096d6;

                color: #fff;
                position: fixed;
                width: 100%;        

            }
            #topNavigationDiv:hover
            {
                opacity: 1;
            }
            #topNavigationDiv a
            {
                color: #fff;
                text-decoration: none;
                margin-right: 20px;
                opacity: 1;
                font-weight: bold;            
            }

            .centerDiv
            {
                padding: 10px;
                margin: 0 auto 0 auto;
                width: 80%;

            }
            #topNavigation
            {
                padding: 10px;
                margin: 0 auto 0 auto;
                width: 80%;
                text-align:right;


            }
            #sliderDescriptionDiv
            {
                padding-top: 200px;
                text-align: right;
                color: #ffffff;


            }
            #sliderDescriptionDiv h1,   #sliderDescriptionDiv p
            {

            }
            #featureRibbonDiv{
                min-height: 200px; 
                background-color: #0096d6;

            }
            #featureRibbon
            {

            }
            #logoDiv
            {
                width: 10%;
                float: left;

            }
            #logoDiv img
            {
                height: 50px;
                margin: -7px;
                padding: 0;
            }
            .featureIteamDiv
            {
                width: 300px;
                float: left;
                margin-right: 20px;
                padding: 10px;
            }
            .clear
            {
                clear: both;
                height: 1px;
            }

            .featureDisplay
            {

                width: 80%;
                margin: 0 auto 0 auto;
                min-height: 300px;
            }
            #featueFullDiv hr
            {
                background-image: linear-gradient(to right, #FFFFFF, #DCDCDC 50%, #FFFFFF);
                background-repeat: no-repeat;
                border: 0 none;
                height: 2px;
                clear: both;
            }
            .featureImageDiv, .featureDiscriptionDiv
            {
                width: 50%; 
                float: left;
            }
            .featureDiscriptionDiv
            {
                padding-top: 150px;
            }
            
            
            
            

        </style>
    </head>
    <body>
        <div id="topNavigationWithSlider">
            <div id="topNavigationDiv">

                <div id="topNavigation">
                    <div id="logoDiv">
                        <img src="<?php echo base_url() . "content/images/logo.png"; ?>"/>

                    </div>
                    <a href="#">HOME</a>
                    <a href="#explore">EXPLORE</a>
                    <a href="#explore">SIGN UP</a>
                </div>


            </div>
            <div class="centerDiv" id="sliderDescriptionDiv">
                <h1>Inventory is your physical wealth.</h1>
                <p>Manage you physical wealth to keep record and investment on the right choice.</p>
            </div>
        </div>
        <div id="featureRibbonDiv">
            <div class="centerDiv" id="featureRibbon">
                <div class="featureIteamDiv">
                    <h3>Feature 1</h3>
                    <p>This is feature 1</p>
                </div>
               
                <div class="featureIteamDiv">
                    <h3>Feature 2</h3>
                    <p>This is feature 2</p>
                </div>
                
                <div class="featureIteamDiv">
                    <h3>Feature 3</h3>
                    <p>This is feature 3</p>
                </div>
                


            </div>
            <div class="clear"></div>
        </div>
        <div id="featueFullDiv">
             <a name="explore"></a> 
            <div class="featureDisplay" id="feature1">
                <div class="featureImageDiv">
                    <img src="<?php echo base_url() . "content/images/uptodate.png"; ?>"/>
                </div>
                <div class="featureDiscriptionDiv">
                    <h1>Be Upto date.</h1>
                    <p>Keep record of your all stuff so that you get the right information about how much inventory is on your hand.</p>
                </div>
                
            </div> 
            <hr>
            
            <div class="featureDisplay" id="feature2">
                <div class="featureDiscriptionDiv">
                    <h1>Billing </h1>
                    <p>Billing is just right click away for your transaction.</p>
                </div>
                <div class="featureImageDiv">
                    <img src="<?php echo base_url() . "content/images/billing.png"; ?>"/>
                </div>
            </div> 
            <hr>
            
           <div class="featureDisplay" id="feature3">
               <div class="featureImageDiv">
                    <img src="<?php echo base_url() . "content/images/access.png"; ?>"/>
                </div>
                <div class="featureDiscriptionDiv">
                    <h1>Accessibility</h1>
                    <p>Access your data from anywhere at anytime. Your inventory is where ever you are.</p>
                </div>
                
            </div> 
            <hr>
            <div class="featureDisplay" id="feature4">
                <div class="featureDiscriptionDiv">
                    <h1>Report</h1>
                    <p>Your daily transaction will not only business it will be your decision for right choice for next day with personalized report.</p>
                </div>
                <div class="featureImageDiv">
                    <img src="<?php echo base_url() . "content/images/report.png"; ?>"/>
                </div>
            </div> 
            <hr>
            <div class="clear"></div>
        </div>
        <div id="featureRibbonDiv">
            <div class="centerDiv" id="featureRibbon">
                <div class="featureIteamDiv">
                    <h3>Feature 1</h3>
                    <p>This is feature 1</p>
                </div>
               
                <div class="featureIteamDiv">
                    <h3>Feature 2</h3>
                    <p>This is feature 2</p>
                </div>
                
                <div class="featureIteamDiv">
                    <h3>Feature 3</h3>
                    <p>This is feature 3</p>
                </div>
                


            </div>
            <div class="clear"></div>
        </div>
    </body>
</html>